package org.generation.blogPessoal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogPessoalApplicationTests {

	@Test
	void contextLoads() {
	}

}
